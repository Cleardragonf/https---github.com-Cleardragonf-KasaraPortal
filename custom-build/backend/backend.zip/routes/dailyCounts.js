"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const mssql_1 = __importStar(require("mssql"));
const utils_1 = require("../utils");
const router = express_1.default.Router();
/**
 * @swagger
 * /api/counts/daily:
 *   get:
 *     summary: Retrieve daily counts based on year, month, and day
 *     description: Fetches daily counts from the `Trans_Dly_Counts` table in the SQL Server database. Filters can be applied for specific year, month, and day.
 *     parameters:
 *       - name: year
 *         in: query
 *         description: The year to filter by
 *         required: false
 *         schema:
 *           type: string
 *       - name: month
 *         in: query
 *         description: The month to filter by
 *         required: false
 *         schema:
 *           type: string
 *       - name: day
 *         in: query
 *         description: The day to filter by
 *         required: false
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Successfully retrieved the data
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   Year:
 *                     type: string
 *                   Month:
 *                     type: string
 *                   Day:
 *                     type: string
 *                   SomeColumn:  # Replace with actual column names
 *                     type: string
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Failed to retrieve data from SQL Server"
 */
router.get('/', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { year, month, day } = req.query;
    let query = 'SELECT * FROM dbo.Trans_Dly_Counts WHERE 1=1';
    const queryParams = [];
    if (year) {
        query += ' AND Year = @Year';
        queryParams.push({ name: 'Year', type: mssql_1.default.NVarChar, value: year });
    }
    if (month) {
        query += ' AND Month = @Month';
        queryParams.push({ name: 'Month', type: mssql_1.default.NVarChar, value: month });
    }
    if (day) {
        query += ' AND Day = @Day';
        queryParams.push({ name: 'Day', type: mssql_1.default.NVarChar, value: day });
    }
    let pool = null;
    try {
        pool = yield new mssql_1.ConnectionPool(utils_1.sqlConfig).connect();
        const request = pool.request();
        queryParams.forEach(param => {
            request.input(param.name, param.type, param.value);
        });
        const result = yield request.query(query);
        res.json(result.recordset);
    }
    catch (error) {
        console.error('SQL Server error:', error);
        res.status(500).json({ error: 'Failed to retrieve data from SQL Server' });
    }
    finally {
        if (pool) {
            yield pool.close();
        }
    }
}));
exports.default = router;
