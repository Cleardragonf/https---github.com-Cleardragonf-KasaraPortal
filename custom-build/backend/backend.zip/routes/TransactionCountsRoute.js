"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransactionCountsRoute = TransactionCountsRoute;
const express_1 = require("express");
const VBScript_1 = require("../process/VBScript");
const ws_1 = __importDefault(require("ws"));
const path_1 = __importDefault(require("path")); // Import the 'path' module to handle file paths
const router = (0, express_1.Router)();
let isProcessing = false;
// Backend WebSocket client that connects to the proxy WebSocket server
const wsClient = new ws_1.default('ws://dhhsedisydvxm:5002'); // Change the URL if necessary
wsClient.on('open', () => {
    console.log('Connected to proxy WebSocket server');
});
wsClient.on('error', (error) => {
    console.error('WebSocket error:', error);
});
/**
 * @swagger
 * tags:
 *   - name: Transactions
 *     description: API to process and manage transactions
 */
/**
 * @swagger
 * /transaction-counts/{transactionType}/{year}/{month}/{processId}:
 *
 *   get:
 *     summary: Get transaction count for a specific transaction type and time period
 *     tags: [Transactions]
 *     parameters:
 *       - in: path
 *         name: transactionType
 *         required: true
 *         schema:
 *           type: string
 *         description: The type of the transaction (e.g., "sale", "refund")
 *       - in: path
 *         name: year
 *         required: true
 *         schema:
 *           type: string
 *         description: The year of the transaction
 *       - in: path
 *         name: month
 *         required: true
 *         schema:
 *           type: string
 *         description: The month of the transaction
 *       - in: path
 *         name: processId
 *         required: true
 *         schema:
 *           type: string
 *         description: The process ID of the transaction request
 *     responses:
 *       200:
 *         description: Transaction count processing started
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Transaction processing started for sale 2025-03"
 *                 processId:
 *                   type: string
 *                   example: "12345"
 *       503:
 *         description: Service unavailable because server is processing another request
 *       500:
 *         description: Internal server error
 */
function TransactionCountsRoute(wss) {
    router.get('/:transactionType/:year/:month/:processId', (req, res, next) => __awaiter(this, void 0, void 0, function* () {
        const { transactionType, year, month, processId } = req.params;
        // const server = os.hostname();  // Get the current server's hostname (DNS name)
        const server = 'localhost'; // Use 'localhost' for testing purposes
        console.log(`Received transaction request for ${transactionType}, ${year}-${month}, processId: ${processId}, server: ${server}`);
        try {
            if (isProcessing) {
                console.log('Server is busy, rejecting request');
                res.status(503).json({ message: 'Server is already processing a request.' });
                return;
            }
            isProcessing = true;
            console.log(`Transaction processing started for ${transactionType} ${year}-${month}`);
            const scriptPath = path_1.default.join(__dirname, '..', 'scripts', `${transactionType}.vbs`);
            // Find an active WebSocket client with a retry mechanism
            function getActiveWebSocket(wss_1) {
                return __awaiter(this, arguments, void 0, function* (wss, retries = 5, delay = 1000) {
                    for (let i = 0; i < retries; i++) {
                        const wsClient = [...wss.clients].find(client => client.readyState === ws_1.default.OPEN);
                        if (wsClient)
                            return wsClient;
                        console.log(`Retrying WebSocket connection... (${i + 1}/${retries})`);
                        yield new Promise(resolve => setTimeout(resolve, delay)); // Wait before retrying
                    }
                    return null;
                });
            }
            try {
                // Pass the required arguments to the VBScript.run method
                yield VBScript_1.VBScript.run(scriptPath, processId, server, transactionType, new Set([wsClient]), year, month);
            }
            catch (error) {
                console.error('VBScript execution error:', error);
                // Send error message if script execution fails
                if (wsClient.readyState === ws_1.default.OPEN) {
                    const errorMessage = {
                        processId,
                        error: 'Script execution failed',
                        details: error.message,
                        server,
                    };
                    wsClient.send(JSON.stringify(errorMessage)); // Send error to the frontend
                }
            }
            isProcessing = false;
            res.json({ message: `Transaction processing started for ${transactionType} ${year}-${month}`, processId });
        }
        catch (error) {
            console.error('Error while processing transaction:', error);
            isProcessing = false;
            res.status(500).json({ message: 'Internal server error' });
        }
    }));
    return router;
}
