"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const child_process_1 = require("child_process");
const utils_1 = require("../utils");
const utils_2 = require("../utils"); // Assuming services are imported from utils.ts
const router = express_1.default.Router();
/**
 * @swagger
 * name: ServerCheck
 * /api/server/{serverId}:
 *   get:
 *     summary: Get server status and service information
 *     description: Pings the specified server, checks system stats, and checks the status of configured services.
 *     parameters:
 *       - name: serverId
 *         in: path
 *         required: true
 *         description: The ID or address of the server to check
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Server status and service information
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 serverId:
 *                   type: string
 *                 status:
 *                   type: string
 *                   example: "online"
 *                 lastChecked:
 *                   type: string
 *                   format: date-time
 *                 responseTime:
 *                   type: integer
 *                   example: 100
 *                 services:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       name:
 *                         type: string
 *                       status:
 *                         type: string
 *                       startupType:
 *                         type: string
 *                       uptime:
 *                         type: string
 *       500:
 *         description: Failed to ping the server or retrieve service status
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Failed to ping server"
 */
router.get('/:serverId', (req, res) => {
    const { serverId } = req.params;
    const pingCommand = `ping -n 1 ${serverId}`;
    (0, child_process_1.exec)(pingCommand, (error, stdout, stderr) => {
        if (error || stderr) {
            const errorMessage = stderr || (error === null || error === void 0 ? void 0 : error.message) || 'Unknown error';
            return res.status(500).json({ error: `Failed to ping server: ${errorMessage}` });
        }
        const isServerOnline = stdout.includes('TTL=');
        const serviceStatuses = [];
        const systemStatsPromise = (0, utils_1.getSystemStats)();
        const serviceChecks = Object.keys(utils_2.services).map((serviceName) => {
            const serviceCommand = `sc qc ${utils_2.services[serviceName]}`;
            return new Promise((resolve) => {
                console.log(`Running service check for: ${serviceName}`);
                (0, child_process_1.exec)(serviceCommand, (serviceError, serviceStdout, serviceStderr) => {
                    console.log(`Service check result for ${serviceName}: ${serviceStdout}`);
                    if (serviceError || serviceStderr) {
                        resolve();
                        return;
                    }
                    console.log(`Service Query Output for ${serviceName}:`, serviceStdout);
                    const startTypeMatch = serviceStdout.match(/START_TYPE\s+:\s+(\d+)/);
                    const startType = startTypeMatch ? startTypeMatch[1] : 'Unknown start type';
                    const isDisabled = startType === '4';
                    let serviceStatus;
                    if (isDisabled) {
                        serviceStatus = 'Disabled';
                    }
                    else {
                        const statusCommand = `sc query ${utils_2.services[serviceName]}`;
                        (0, child_process_1.exec)(statusCommand, (statusError, statusStdout, statusStderr) => {
                            if (statusError || statusStderr) {
                                serviceStatus = 'Unknown';
                            }
                            else {
                                serviceStatus = statusStdout.includes('RUNNING') ? 'Running' : 'Stopped';
                            }
                            // Extract start time from the output
                            const startTimeMatch = statusStdout.match(/START_TIME\s+:\s+(\S+ \S+)/);
                            const startTimeStr = startTimeMatch ? startTimeMatch[1] : 'Unknown start time';
                            console.log(`Start Time for ${serviceName}: ${startTimeStr}`);
                            // Try parsing the date
                            const startTimeDate = new Date(startTimeStr);
                            const uptime = !isNaN(startTimeDate.getTime())
                                ? (0, utils_1.formatUptime)(Date.now() - startTimeDate.getTime())
                                : 'Unknown uptime'; // Fallback in case of invalid date
                            // Push the service status data into the serviceStatuses array
                            serviceStatuses.push({
                                name: serviceName,
                                status: serviceStatus,
                                startupType: startType,
                                isDisabled,
                                uptime,
                            });
                            resolve();
                        });
                        return;
                    }
                    // Fallback code to handle disabled or unknown status cases
                    const startTimeMatch = serviceStdout.match(/START_TIME\s+:\s+(\S+ \S+)/);
                    const startTimeStr = startTimeMatch ? startTimeMatch[1] : 'Unknown start time';
                    const startTimeDate = new Date(startTimeStr);
                    const uptime = !isNaN(startTimeDate.getTime())
                        ? (0, utils_1.formatUptime)(Date.now() - startTimeDate.getTime())
                        : 'Unknown uptime';
                    serviceStatuses.push({
                        name: serviceName,
                        status: serviceStatus,
                        startupType: startType,
                        isDisabled,
                        uptime,
                    });
                    resolve();
                });
            });
        });
        // Wait for all the service checks and system stats to complete
        Promise.all([systemStatsPromise, ...serviceChecks]).then(([systemStats]) => {
            res.json({
                serverId,
                status: isServerOnline ? 'online' : 'online',
                lastChecked: new Date(),
                responseTime: 100, // Optional: can be calculated from ping result
                services: serviceStatuses,
                systemStats,
            });
        });
    });
});
/**
 * @swagger
 * /api/server/{serverId}/{service}/{status}:
 *   post:
 *     summary: Manage service status
 *     description: Starts, stops, restarts, disables, or enables a specified service on a given server.
 *     parameters:
 *       - name: serverId
 *         in: path
 *         required: true
 *         description: The ID or address of the server to manage
 *         schema:
 *           type: string
 *       - name: service
 *         in: path
 *         required: true
 *         description: The name of the service to manage
 *         schema:
 *           type: string
 *       - name: status
 *         in: path
 *         required: true
 *         description: The action to perform on the service (start, stop, restart, disable, enable)
 *         schema:
 *           type: string
 *           enum:
 *             - start
 *             - stop
 *             - restart
 *             - disable
 *             - enable
 *     responses:
 *       200:
 *         description: Successfully managed the service
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Service started successfully."
 *       404:
 *         description: Service not found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Service xyz not found"
 *       400:
 *         description: Invalid status value
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Invalid status. Allowed values are 'start', 'stop', 'restart', 'disable', 'enable'."
 *       500:
 *         description: Failed to manage the service
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Failed to start service: Unknown error"
 */
router.post('/:serverId/:service/:status', (req, res) => {
    const { serverId, service, status } = req.params;
    if (!utils_2.services[service]) {
        res.status(404).json({ error: `Service ${service} not found` });
        return;
    }
    const serviceName = utils_2.services[service];
    const isValidStatus = ['start', 'stop', 'restart', 'disable', 'enable'].includes(status.toLowerCase());
    if (!isValidStatus) {
        res.status(400).json({ error: `Invalid status. Allowed values are 'start', 'stop', 'restart', 'disable', 'enable'.` });
        return;
    }
    const startService = () => {
        (0, child_process_1.exec)(`sc start ${serviceName}`, (error, stdout, stderr) => {
            var _a;
            if (error || stderr) {
                const errorMessage = (_a = stderr !== null && stderr !== void 0 ? stderr : error === null || error === void 0 ? void 0 : error.message) !== null && _a !== void 0 ? _a : 'Unknown error';
                return res.status(500).json({ error: `Failed to start service: ${errorMessage}` });
            }
            return res.json({ message: `Service ${service} started successfully.` });
        });
    };
    const stopService = () => {
        (0, child_process_1.exec)(`sc stop ${serviceName}`, (error, stdout, stderr) => {
            var _a;
            if (error || stderr) {
                const errorMessage = (_a = stderr !== null && stderr !== void 0 ? stderr : error === null || error === void 0 ? void 0 : error.message) !== null && _a !== void 0 ? _a : 'Unknown error';
                return res.status(500).json({ error: `Failed to stop service: ${errorMessage}` });
            }
            return res.json({ message: `Service ${service} stopped successfully.` });
        });
    };
    const restartService = () => {
        (0, child_process_1.exec)(`sc stop ${serviceName}`, (stopError, stopStdout, stopStderr) => {
            var _a;
            if (stopError || stopStderr) {
                const errorMessage = (_a = stopStderr !== null && stopStderr !== void 0 ? stopStderr : stopError === null || stopError === void 0 ? void 0 : stopError.message) !== null && _a !== void 0 ? _a : 'Unknown error';
                return res.status(500).json({ error: `Failed to stop service: ${errorMessage}` });
            }
            setTimeout(() => {
                (0, child_process_1.exec)(`sc start ${serviceName}`, (startError, startStdout, startStderr) => {
                    var _a;
                    if (startError || startStderr) {
                        const errorMessage = (_a = startStderr !== null && startStderr !== void 0 ? startStderr : startError === null || startError === void 0 ? void 0 : startError.message) !== null && _a !== void 0 ? _a : 'Unknown error';
                        return res.status(500).json({ error: `Failed to start service: ${errorMessage}` });
                    }
                    return res.json({ message: `Service ${service} restarted successfully.` });
                });
            }, 2000);
        });
    };
    const disableService = () => {
        (0, child_process_1.exec)(`sc stop ${serviceName}`, (stopError, stopStdout, stopStderr) => {
            var _a;
            if (stopError || stopStderr) {
                const errorMessage = (_a = stopStderr !== null && stopStderr !== void 0 ? stopStderr : stopError === null || stopError === void 0 ? void 0 : stopError.message) !== null && _a !== void 0 ? _a : 'Unknown error';
                return res.status(500).json({ error: `Failed to stop service: ${errorMessage}` });
            }
            (0, child_process_1.exec)(`sc config ${serviceName} start= disabled`, (configError, configStdout, configStderr) => {
                var _a;
                if (configError || configStderr) {
                    const errorMessage = (_a = configStderr !== null && configStderr !== void 0 ? configStderr : configError === null || configError === void 0 ? void 0 : configError.message) !== null && _a !== void 0 ? _a : 'Unknown error';
                    return res.status(500).json({ error: `Failed to disable service: ${errorMessage}` });
                }
                return res.json({ message: `Service ${service} disabled successfully.` });
            });
        });
    };
    const enableService = () => {
        (0, child_process_1.exec)(`sc config ${serviceName} start= demand`, (configError, configStdout, configStderr) => {
            var _a;
            if (configError || configStderr) {
                const errorMessage = (_a = configStderr !== null && configStderr !== void 0 ? configStderr : configError === null || configError === void 0 ? void 0 : configError.message) !== null && _a !== void 0 ? _a : 'Unknown error';
                return res.status(500).json({ error: `Failed to enable service: ${errorMessage}` });
            }
            return res.json({ message: `Service ${service} enabled successfully.` });
        });
    };
    switch (status.toLowerCase()) {
        case 'start':
            startService();
            break;
        case 'stop':
            stopService();
            break;
        case 'restart':
            restartService();
            break;
        case 'disable':
            disableService();
            break;
        case 'enable':
            enableService();
            break;
        default:
            res.status(400).json({ error: `Invalid status value. Use 'start', 'stop', 'restart', 'disable', or 'enable'.` });
            break;
    }
});
exports.default = router;
