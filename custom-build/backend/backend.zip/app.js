"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const ws_1 = require("ws");
const serverCheck_1 = __importDefault(require("./routes/serverCheck"));
const dailyCounts_1 = __importDefault(require("./routes/dailyCounts"));
const TransactionCountsRoute_1 = require("./routes/TransactionCountsRoute");
const http_1 = __importDefault(require("http"));
const swagger_jsdoc_1 = __importDefault(require("swagger-jsdoc"));
const swagger_ui_express_1 = __importDefault(require("swagger-ui-express"));
const app = (0, express_1.default)();
const server = http_1.default.createServer(app); // Create an HTTP server
const wss = new ws_1.WebSocketServer({ server }); // Attach WebSocket Server
app.use(express_1.default.json());
// Swagger setup
const swaggerOptions = {
    definition: {
        openapi: '3.0.0',
        info: {
            title: 'API Documentation',
            version: '1.0.0',
            description: 'API documentation for the backend',
        },
    },
    apis: ['./src/routes/serverCheck.ts', './src/routes/dailyCounts.ts', './src/routes/TransactionCountsRoute.ts'], // Corrected to .ts paths
};
const swaggerSpec = (0, swagger_jsdoc_1.default)(swaggerOptions);
// Swagger UI route
app.use('/docs', swagger_ui_express_1.default.serve, swagger_ui_express_1.default.setup(swaggerSpec));
// Use the routes
app.use('/api/server_Check', serverCheck_1.default);
app.use('/api/counts/daily', dailyCounts_1.default);
app.use('/api/TransactionCounts/Start', (0, TransactionCountsRoute_1.TransactionCountsRoute)(wss));
const PORT = process.env.PORT || 9277;
const activeProcesses = {};
wss.on('connection', (ws) => {
    console.log('Client connected to Backend WebSocket');
    ws.on('message', (message) => {
        const { type, data } = JSON.parse(message.toString());
        if (type === 'process') {
            const processId = `proc-${Date.now()}`;
            activeProcesses[processId] = { ws, status: 'Processing started' };
            ws.send(JSON.stringify({ processId, update: 'Processing started' }));
            // Simulate process execution with live updates
            setTimeout(() => {
                activeProcesses[processId].status = 'Processing 50% done';
                ws.send(JSON.stringify({ processId, update: 'Processing 50% done' }));
            }, 3000);
            setTimeout(() => {
                activeProcesses[processId].status = 'Processing completed';
                ws.send(JSON.stringify({ processId, update: 'Processing completed' }));
                // Cleanup
                delete activeProcesses[processId];
                ws.close();
            }, 6000);
        }
    });
    ws.on('close', () => console.log('Client disconnected from Backend WebSocket'));
});
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
