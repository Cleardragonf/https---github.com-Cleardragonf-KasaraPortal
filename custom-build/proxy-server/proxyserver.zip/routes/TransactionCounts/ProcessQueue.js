"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const mssql_1 = __importDefault(require("mssql"));
const utils_1 = require("../../utils"); // Assuming SQL config is here
const router = express_1.default.Router();
router.use(express_1.default.json()); // Middleware for JSON parsing
// Create a new row (POST)
router.post('/create', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { processId, weight, transactionType, year, month, status, server, position } = req.body;
    try {
        const pool = yield mssql_1.default.connect(utils_1.TranslatorPortal);
        yield pool.request()
            .input('processId', mssql_1.default.UniqueIdentifier, processId)
            .input('weight', mssql_1.default.Int, weight)
            .input('transactionType', mssql_1.default.VarChar(30), transactionType)
            .input('year', mssql_1.default.Char(4), year)
            .input('month', mssql_1.default.Char(6), month)
            .input('status', mssql_1.default.VarChar(30), status)
            .input('server', mssql_1.default.VarChar(30), server || null)
            .input('position', mssql_1.default.Int, position)
            .query(`
        INSERT INTO dbo.ProcessQueue 
        (processId, weight, transactionType, year, month, status, server, position)
        VALUES (@processID, @weight, @transactionType, @year, @month, @status,  @server, @position);
      `);
        res.status(201).json({ message: 'Row created successfully' });
    }
    catch (error) {
        console.error('Error creating row:', error);
        res.status(500).json({ message: 'Error creating row', error });
    }
}));
// Edit an existing row (PUT)
router.put('/edit/:processID', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { processID } = req.params;
    const { position, weight, transactionType, year, month, status, startedDate, server } = req.body;
    try {
        const pool = yield mssql_1.default.connect(utils_1.TranslatorPortal);
        yield pool.request()
            .input('processID', mssql_1.default.UniqueIdentifier, processID)
            .input('position', mssql_1.default.Int, position)
            .input('weight', mssql_1.default.Int, weight)
            .input('transactionType', mssql_1.default.VarChar(30), transactionType)
            .input('year', mssql_1.default.Char(4), year)
            .input('month', mssql_1.default.Char(6), month)
            .input('status', mssql_1.default.VarChar(30), status)
            .input('startedDate', mssql_1.default.DateTime, startedDate || null)
            .input('server', mssql_1.default.VarChar(30), server || null)
            .query(`
        UPDATE dbo.ProcessQueue
        SET 
          position = @position,
          weight = @weight,
          transactionType = @transactionType,
          year = @year,
          month = @month,
          status = @status,
          startedDate = @startedDate,
          server = @server
        WHERE processID = @processID;
      `);
        res.status(200).json({ message: 'Row updated successfully' });
    }
    catch (error) {
        console.error('Error updating row:', error);
        res.status(500).json({ message: 'Error updating row', error });
    }
}));
// Delete a row (DELETE)
router.delete('/delete/:processID', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { processID } = req.params;
    try {
        const pool = yield mssql_1.default.connect(utils_1.TranslatorPortal);
        yield pool.request()
            .input('processID', mssql_1.default.UniqueIdentifier, processID)
            .query(`DELETE FROM dbo.ProcessQueue WHERE processID = @processID;`);
        res.status(200).json({ message: 'Row deleted successfully' });
    }
    catch (error) {
        console.error('Error deleting row:', error);
        res.status(500).json({ message: 'Error deleting row', error });
    }
}));
// Get all rows (GET)
router.get('/', (_req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const pool = yield mssql_1.default.connect(utils_1.TranslatorPortal);
        const result = yield pool.request()
            .query(`SELECT * FROM dbo.ProcessQueue ORDER BY createdDate DESC;`);
        // Map the result and format it according to the desired structure
        const formattedData = result.recordset.map(row => ({
            type: 'process',
            status: row.status,
            data: {
                processId: row.processID,
                month: row.month,
                year: row.year,
                transactionType: row.transactionType,
                position: row.position,
                weight: row.weight,
                // Add any other fields you want to include here
            }
        }));
        // Send the formatted response
        res.status(200).json(formattedData);
    }
    catch (error) {
        console.error('Error fetching rows:', error);
        res.status(500).json({ message: 'Error fetching rows', error });
    }
}));
// Get a specific row by processID (GET)
router.get('/:processID', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { processID } = req.params;
    try {
        const pool = yield mssql_1.default.connect(utils_1.TranslatorPortal);
        const result = yield pool.request()
            .input('processID', mssql_1.default.UniqueIdentifier, processID)
            .query(`SELECT * FROM dbo.ProcessQueue WHERE processID = @processID;`);
        if (result.recordset.length > 0) {
            res.status(200).json(result.recordset[0]);
        }
        else {
            res.status(404).json({ message: 'Row not found' });
        }
    }
    catch (error) {
        console.error('Error fetching row:', error);
        res.status(500).json({ message: 'Error fetching row', error });
    }
}));
exports.default = router;
