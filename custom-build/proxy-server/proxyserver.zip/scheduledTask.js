"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.initializeScheduledTask = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const axios_1 = __importDefault(require("axios"));
const node_cron_1 = __importDefault(require("node-cron")); // Replace node-schedule with node-cron
const unzipper = __importStar(require("unzipper"));
const winston_1 = __importDefault(require("winston"));
// Logger setup
const logger = winston_1.default.createLogger({
    level: 'info',
    format: winston_1.default.format.combine(winston_1.default.format.timestamp(), winston_1.default.format.json()),
    transports: [
        new winston_1.default.transports.Console(),
        new winston_1.default.transports.File({ filename: 'scheduledTask.log' }),
    ],
});
// Environment variables for paths
const SHARED_FILE_PATH = '\\\\dhhsfs1.hhss.local\\epm$\\_TranslatorTeam\\TranslatorPortal\\versions.json';
const PROXYSERVER_DOWNLOAD_URL = '\\\\dhhsfs1.hhss.local\\epm$\\_TranslatorTeam\\TranslatorPortal\\proxy-server\\proxyserver.zip';
const FRONTEND_DOWNLOAD_URL = '\\\\dhhsfs1.hhss.local\\epm$\\_TranslatorTeam\\TranslatorPortal\\frontend\\frontend.zip';
const FRONTEND_DIR = path_1.default.join('C:\\TranslatorPortal\\nginx-1.27.4\\html');
const PROXYSERVER_DIR = path_1.default.join(__dirname);
let currentVersions = {
    proxyserver: null,
    frontend: null,
    backend: null,
};
// Initialize current versions
const initializeCurrentVersions = () => {
    if (fs_1.default.existsSync(SHARED_FILE_PATH)) {
        const fileContent = fs_1.default.readFileSync(SHARED_FILE_PATH, 'utf-8');
        const versions = JSON.parse(fileContent);
        if (isValidVersionFile(versions)) {
            currentVersions.proxyserver = versions.proxyserver || null;
            currentVersions.frontend = versions.frontend || null;
            currentVersions.backend = versions.backend || null;
        }
        else {
            logger.error('Invalid version file format during initialization.');
        }
    }
    else {
        logger.warn('Shared file not found during initialization. Using default versions.');
    }
};
// Validate JSON structure
const isValidVersionFile = (data) => {
    if (!data || typeof data !== 'object') {
        logger.error('Version file is not a valid object.');
        return false;
    }
    const isValidComponent = (component) => component &&
        typeof component.version === 'string' &&
        typeof component.updateUrl === 'string';
    if (!isValidComponent(data.proxyserver)) {
        logger.error('Invalid or missing "proxyserver" field in version file.');
        return false;
    }
    if (!isValidComponent(data.frontend)) {
        logger.error('Invalid or missing "frontend" field in version file.');
        return false;
    }
    if (!isValidComponent(data.backend)) {
        logger.error('Invalid or missing "backend" field in version file.');
        return false;
    }
    return true;
};
// Check for updates
const checkForUpdates = () => {
    var _a, _b, _c, _d, _e, _f;
    if (!fs_1.default.existsSync(SHARED_FILE_PATH)) {
        console.log('Shared file not found:', SHARED_FILE_PATH);
        logger.error('Shared file not found:', SHARED_FILE_PATH);
        return;
    }
    const fileContent = fs_1.default.readFileSync(SHARED_FILE_PATH, 'utf-8');
    const newVersions = JSON.parse(fileContent);
    if (!isValidVersionFile(newVersions)) {
        logger.error('Invalid version file format.');
        return;
    }
    if (((_a = newVersions.proxyserver) === null || _a === void 0 ? void 0 : _a.version) !== ((_b = currentVersions.proxyserver) === null || _b === void 0 ? void 0 : _b.version)) {
        handleProxyServerUpdate(newVersions.proxyserver);
    }
    if (((_c = newVersions.frontend) === null || _c === void 0 ? void 0 : _c.version) !== ((_d = currentVersions.frontend) === null || _d === void 0 ? void 0 : _d.version)) {
        logger.info('Frontend update detected. Downloading...');
        if (newVersions.frontend) {
            downloadWithRetry(newVersions.frontend.updateUrl, FRONTEND_DIR, 'frontend.zip', newVersions.frontend.version);
        }
        currentVersions.frontend = newVersions.frontend;
    }
    if (((_e = newVersions.backend) === null || _e === void 0 ? void 0 : _e.version) !== ((_f = currentVersions.backend) === null || _f === void 0 ? void 0 : _f.version)) {
        logger.info('Backend update detected. Please handle backend updates manually.');
        currentVersions.backend = newVersions.backend;
    }
};
// Handle proxy server updates
const handleProxyServerUpdate = (newVersion) => {
    logger.info('Proxy server update detected. Downloading...');
    downloadWithRetry(newVersion.updateUrl, PROXYSERVER_DIR, 'proxyserver.zip', newVersion.version);
    currentVersions.proxyserver = newVersion;
};
// Verify update
const verifyUpdate = (expectedVersion, targetDir) => {
    try {
        const packageJsonPath = path_1.default.join(targetDir, 'package.json'); // Assume package.json exists in the extracted files
        if (!fs_1.default.existsSync(packageJsonPath)) {
            logger.error(`package.json not found in ${targetDir}`);
            return false;
        }
        const packageJsonContent = fs_1.default.readFileSync(packageJsonPath, 'utf-8');
        const packageJson = JSON.parse(packageJsonContent);
        if (packageJson.version === expectedVersion) {
            logger.info(`Update verification successful. Version: ${packageJson.version}`);
            return true;
        }
        else {
            logger.info(`Version mismatch detected. Expected: ${expectedVersion}, Found: ${packageJson.version}`);
            updatePackageVersion(expectedVersion);
            restartApplication();
            return true; // Consider this a successful update
        }
    }
    catch (error) {
        logger.error('Error verifying update:', error);
        return false;
    }
};
const updatePackageVersion = (newVersion) => {
    try {
        const packageJsonPath = path_1.default.join(__dirname, '../package.json');
        const packageJsonContent = fs_1.default.readFileSync(packageJsonPath, 'utf-8');
        const packageJson = JSON.parse(packageJsonContent);
        packageJson.version = newVersion; // Update the version
        fs_1.default.writeFileSync(packageJsonPath, JSON.stringify(packageJson, null, 2), 'utf-8');
        logger.info(`Updated package.json version to ${newVersion}`);
    }
    catch (error) {
        logger.error('Error updating package.json version:', error);
    }
};
const restartApplication = () => {
    try {
        logger.info('Restarting application...');
        process.exit(0); // Exit the process to allow a process manager (e.g., PM2, systemd) to restart the app
    }
    catch (error) {
        logger.error('Error restarting application:', error);
    }
};
// Download with retry logic
const downloadWithRetry = (url, targetDir, fileName, expectedVersion, retries = 3) => __awaiter(void 0, void 0, void 0, function* () {
    for (let attempt = 1; attempt <= retries; attempt++) {
        try {
            yield downloadAndUpdate(url, targetDir, fileName, expectedVersion);
            return;
        }
        catch (error) {
            logger.error(`Attempt ${attempt} failed for ${fileName}:`, error);
            if (attempt === retries) {
                logger.error(`Failed to download ${fileName} after ${retries} attempts.`);
            }
        }
    }
});
// Download and update
const downloadAndUpdate = (url, targetDir, fileName, expectedVersion) => __awaiter(void 0, void 0, void 0, function* () {
    const filePath = path_1.default.join(targetDir, fileName);
    try {
        if (url.startsWith('\\\\') || path_1.default.isAbsolute(url)) {
            // Handle UNC path or absolute file path by copying the file locally
            logger.info(`Copying file from UNC or local path: ${url}`);
            if (!fs_1.default.existsSync(url)) {
                throw new Error(`File not found at UNC path: ${url}`);
            }
            fs_1.default.copyFileSync(url, filePath);
        }
        else {
            // Handle HTTP/HTTPS URLs
            logger.info(`Downloading file from URL: ${url}`);
            const response = yield axios_1.default.get(url, { responseType: 'stream' });
            const writer = fs_1.default.createWriteStream(filePath);
            response.data.pipe(writer);
            yield new Promise((resolve, reject) => {
                writer.on('finish', resolve);
                writer.on('error', reject);
            });
        }
        logger.info(`${fileName} downloaded/copied successfully.`);
        yield extractAndReplace(filePath, targetDir);
        // Verify the update if an expected version is provided
        if (expectedVersion) {
            const isVerified = verifyUpdate(expectedVersion, targetDir);
            if (!isVerified) {
                logger.error('Update verification failed.');
            }
        }
    }
    catch (error) {
        logger.error(`Error downloading or copying ${fileName}:`, error);
    }
    finally {
        if (fs_1.default.existsSync(filePath)) {
            fs_1.default.unlinkSync(filePath); // Clean up the zip file
        }
    }
});
// Extract and replace files
const extractAndReplace = (filePath, targetDir) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        yield new Promise((resolve, reject) => {
            fs_1.default.createReadStream(filePath)
                .pipe(unzipper.Extract({ path: targetDir }))
                .on('close', resolve)
                .on('error', reject);
        });
        logger.info(`Extracted ${filePath} to ${targetDir}`);
        fs_1.default.unlinkSync(filePath); // Clean up the zip file
    }
    catch (error) {
        logger.error(`Error extracting ${filePath}:`, error);
    }
});
// Export initialization and scheduling logic
const initializeScheduledTask = () => {
    initializeCurrentVersions();
    node_cron_1.default.schedule('* * * * *', checkForUpdates); // Use cron to schedule the task every minute
    logger.info('Scheduled task started. Monitoring for updates...');
};
exports.initializeScheduledTask = initializeScheduledTask;
