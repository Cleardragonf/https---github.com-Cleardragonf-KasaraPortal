"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.wss = exports.getAvailableServer = exports.serverStatus = exports.serverMapping = void 0;
const express_1 = __importDefault(require("express"));
const http_proxy_middleware_1 = require("http-proxy-middleware");
const dailyCounts_1 = __importDefault(require("./routes/TransactionCounts/dailyCounts"));
const Schedule_1 = __importDefault(require("./routes/TransactionCounts/Schedule"));
const ws_1 = require("ws");
const node_fetch_1 = __importDefault(require("node-fetch")); // Ensure fetch is available
const crypto_1 = __importDefault(require("crypto"));
const ProcessQueue_1 = __importDefault(require("./routes/TransactionCounts/ProcessQueue"));
const ProcessCleaner_1 = require("./process/DBProccedures/ProcessCleaner"); // Adjust the path if necessary
const ProcessQueueProcess_1 = require("./process/TransactionCounts/ProcessQueueProcess");
const runScheduler_1 = require("./process/TransactionCounts/runScheduler");
const scheduledTask_1 = require("./scheduledTask");
const app = (0, express_1.default)();
const port = 5001;
// Middleware
app.use(express_1.default.json());
// WebSocket Server
const wss = new ws_1.WebSocketServer({ port: 5002 });
exports.wss = wss;
const clients = new Set();
const processCleaner = ProcessCleaner_1.ProcessCleaner.getInstance();
processCleaner.scheduleTask();
(0, ProcessQueueProcess_1.checkAndStartWaitingProcess)();
const process = runScheduler_1.SchedulerProcess.getInstance();
process.scheduleTask();
// Initialize the scheduled task
(0, scheduledTask_1.initializeScheduledTask)();
wss.on('connection', (ws) => {
    console.log('Frontend connected via WebSocket');
    clients.add(ws);
    ws.on('message', (message) => __awaiter(void 0, void 0, void 0, function* () {
        // Log raw message and convert buffer to string
        console.log('Raw message received from frontend:', message);
        // Convert the buffer to string
        const messageString = message.toString();
        // Parse the message as JSON
        try {
            const parsedMessage = JSON.parse(messageString);
            // Check if the message is a "start transaction" message
            if (parsedMessage.type === 'process' && parsedMessage.data && parsedMessage.status === 'starting') {
                const { transactionType, year, month, processId } = parsedMessage.data;
                console.log(`Start transaction for: ${transactionType}, ${year}-${month}, ID: ${processId}`);
                // Trigger the API call to start the transaction
                const availableServer = (0, exports.getAvailableServer)();
                if (!availableServer) {
                    ws.send(JSON.stringify({ type: 'error', message: 'No available servers' }));
                    return;
                }
                exports.serverStatus[availableServer] = true; // Mark server as busy
                const serverUrl = `${exports.serverMapping[availableServer]}/api/TransactionCounts/Start/${transactionType}/${year}/${month}/${processId}`;
                try {
                    const response = yield (0, node_fetch_1.default)(serverUrl, { method: 'GET' });
                    // Log the full response
                    const data = yield response.json();
                    console.log('Backend response data:', data);
                    const broadcastData = {
                        processId,
                        server: availableServer,
                        month,
                        year,
                        transactionType,
                    };
                    // If the response is successful, notify the WebSocket
                    // broadcast({
                    //     type: 'process',
                    //     status: 'Update',
                    //     message: `Server Found: ${availableServer}`,
                    //     data: broadcastData
                    // });
                }
                catch (error) {
                    console.error("Error while starting transaction:", error);
                    exports.serverStatus[availableServer] = false; // Mark as available on failure
                    ws.send(JSON.stringify({ type: 'error', message: 'Error starting transaction' }));
                }
            }
            else if (parsedMessage.type === 'process' && parsedMessage.data && parsedMessage.status === 'update') {
                const { processId, server } = parsedMessage.data;
                console.log(`Received process update for process ID: ${processId} on server: ${server}`);
                // Notify WebSocket clients
                broadcast({ type: 'process', status: 'Update', message: `${parsedMessage.message}`, data: parsedMessage.data });
            }
            else if (parsedMessage.type === 'process' && parsedMessage.data && parsedMessage.status === 'error') {
                console.log(`Received process error for process ID: ${parsedMessage.data.processId} on server: ${parsedMessage.data.server}`);
                broadcast({ type: 'process', status: 'error', message: `${parsedMessage.message}`, data: parsedMessage.data });
                const { processId, server } = parsedMessage.data;
                if (exports.serverStatus[server] !== undefined) {
                    exports.serverStatus[server] = false;
                    console.log(`Server ${server} is now available.`);
                }
                delete processMapping[processId];
            }
            else if (parsedMessage.type === 'process' && parsedMessage.data && parsedMessage.status === 'complete') {
                const { processId, server, transactionType, year, month } = parsedMessage.data;
                // Mark the server as available again
                if (exports.serverStatus[server] !== undefined) {
                    exports.serverStatus[server] = false;
                    console.log(`Server ${server} is now available.`);
                }
                // Remove process from mapping if stored
                delete processMapping[processId];
                // Notify WebSocket clients about the process completion first
                broadcast({
                    type: 'process',
                    status: 'complete',
                    message: `${parsedMessage.message}`,
                    data: parsedMessage.data
                });
                // Define the URL to update the last successful run in the Schedule
                const updateLastRunURL = `http://localhost:5001/api/TransactionCounts/Schedule/updateLastRun/${processId}`;
                // Define specific data to send with the update
                const processUpdateData = {
                    year: year,
                    month: month,
                    processId,
                    transactionType: transactionType,
                    status: 'complete',
                    server,
                    lastSuccessfulRun: new Date().toISOString(), // Ensure this field is correctly sent to the backend
                };
                // Make the API call in a non-blocking manner
                setImmediate(() => __awaiter(void 0, void 0, void 0, function* () {
                    try {
                        const response = yield (0, node_fetch_1.default)(updateLastRunURL, {
                            method: 'PUT',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify(processUpdateData)
                        });
                        // Log the status and raw response if it's not OK
                        if (!response.ok) {
                            console.error(`API error: ${response.status} - ${response.statusText}`);
                            const text = yield response.text(); // Log the raw response if it's not OK
                            console.error('Raw response body:', text);
                            return;
                        }
                        const data = yield response.json();
                        console.log('Schedule update response for Completion:', data);
                        // Log the LastSuccessfulRun field to verify it is being updated
                        if (data && typeof data === 'object') {
                            const lastSuccessfulRun = data.LastSuccessfulRun;
                            if (lastSuccessfulRun) {
                                console.log('LastSuccessfulRun updated to:', lastSuccessfulRun);
                            }
                            else {
                                console.warn('LastSuccessfulRun field is missing or not updated. Ensure the backend includes it in the response.');
                            }
                        }
                        else {
                            console.warn('Unexpected response format. Check backend implementation.');
                        }
                        // After 3 minutes, trigger the delete operation for this process
                        setTimeout(() => __awaiter(void 0, void 0, void 0, function* () {
                            try {
                                const deleteProcessURL = `http://localhost:5001/api/TransactionCounts/ProcessQueue/delete/${processId}`;
                                const deleteResponse = yield (0, node_fetch_1.default)(deleteProcessURL, {
                                    method: 'DELETE'
                                });
                                // Handle response
                                if (!deleteResponse.ok) {
                                    console.error(`API error: ${deleteResponse.status} - ${deleteResponse.statusText}`);
                                    const text = yield deleteResponse.text();
                                    console.error('Raw response body:', text);
                                }
                                else {
                                    console.log(`Process ${processId} deleted successfully after 3 minutes.`);
                                }
                            }
                            catch (error) {
                                console.error("Error while deleting process:", error);
                            }
                        }), 180000); // 3 minutes = 180000 milliseconds
                    }
                    catch (error) {
                        console.error("Error while updating schedule:", error);
                    }
                }));
            }
            else {
                // Handle any other message types that don't match the above condition
                console.log('Received an unrecognized message:', parsedMessage);
                ws.send(JSON.stringify({ type: 'error', message: 'Unrecognized message type or missing data' }));
            }
        }
        catch (error) {
            console.error("Error parsing WebSocket message:", error);
            ws.send(JSON.stringify({ type: 'error', message: 'Invalid message format' }));
        }
    }));
    ws.on('close', () => {
        console.log('Frontend WebSocket disconnected');
        clients.delete(ws);
    });
});
// Function to broadcast messages to WebSocket clients
const broadcast = (message) => {
    clients.forEach(client => {
        if (client.readyState === ws_1.WebSocket.OPEN) {
            client.send(JSON.stringify(message));
        }
    });
};
exports.serverMapping = {
    localhost: 'http://localhost:9277',
    DHHSEDIDevProc: 'http://DHHSEDIDevProc:9277',
    DHHSEDIDevRte: 'http://DHHSEDIDevRte:9277',
    DHSEDIDevOR: 'http://DHSEDIDevOR:9277',
};
// Server Availability Tracking
exports.serverStatus = {
    localhost: false,
    DHHSEDIDevProc: true,
    DHHSEDIDevRte: true,
    DHSEDIDevOR: true,
};
// Find Available Server
const getAvailableServer = () => {
    for (const [server, isBusy] of Object.entries(exports.serverStatus)) {
        if (!isBusy)
            return server;
    }
    return null;
};
exports.getAvailableServer = getAvailableServer;
// Get Backend Server URL
const getServerUrl = (serverName) => {
    return exports.serverMapping[serverName];
};
// Dynamic Routing
app.use('/api/server_Check/:serverName', (req, res, next) => {
    let { serverName } = req.params;
    console.log(`Received request for server: ${serverName}`);
    serverName = serverName.replace(/^\/+|\/+$/g, ''); // Clean input
    console.log(`Cleaned server name: ${serverName}`);
    const serverUrl = getServerUrl(serverName);
    if (serverUrl) {
        console.log(`Proxying to: ${serverUrl}/api/server_Check/${serverName}`);
        (0, http_proxy_middleware_1.createProxyMiddleware)({
            target: `${serverUrl}/api/server_Check/${serverName}`,
            changeOrigin: true,
            onError(err, _req, res) {
                console.error(`Error connecting to ${serverUrl}:`, err);
                res.status(500).json({ message: 'Error connecting to backend', error: err.message });
            },
        })(req, res, next);
    }
    else {
        res.status(404).json({ message: 'Server not found' });
    }
});
const processMapping = {}; // Store process IDs
app.get('/api/TransactionCounts/Start/:transactionType/:year/:month', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { transactionType, year, month } = req.params;
    const availableServer = (0, exports.getAvailableServer)();
    if (!availableServer) {
        res.status(503).json({ message: 'No available servers. Try again later.' });
        return;
    }
    exports.serverStatus[availableServer] = true; // Mark as busy
    const serverUrl = `${exports.serverMapping[availableServer]}/api/TransactionCounts/Start/${transactionType}/${year}/${month}`;
    const processId = crypto_1.default.randomUUID(); // Generate a unique UUID for the transaction
    // Store the process ID and server in the processMapping
    processMapping[processId] = availableServer;
    try {
        const response = yield (0, node_fetch_1.default)(serverUrl, { method: 'GET' });
        // Type assertion for response data
        const data = yield response.json();
        // Notify WebSocket clients
        broadcast({ type: 'process', status: 'Update', server: availableServer, transactionType, year, month, processId });
        res.json({ message: `Process '${transactionType}' for ${year}-${month} started on ${availableServer}`, processId, data });
    }
    catch (error) {
        exports.serverStatus[availableServer] = false; // Reset status on failure
        res.status(500).json({ message: 'Error starting process', error });
    }
}));
// Backend Reports Process Completion
app.post('/api/reportCompletion/:serverName/:processId', (req, res) => {
    const { serverName, processId } = req.params;
    if (exports.serverStatus[serverName] !== undefined) {
        // Check if the processId exists in the processMapping
        const serverForProcess = processMapping[processId];
        if (!serverForProcess || serverForProcess !== serverName) {
            res.status(400).json({ message: 'Invalid process ID or mismatched server' });
        }
        // Mark the server as available now
        exports.serverStatus[serverName] = false;
        const broadcastData = {
            processId,
        };
        // Notify WebSocket clients of process completion
        broadcast({ type: 'process', status: 'complete', server: serverName, data: broadcastData });
        res.json({ message: `Process with ID '${processId}' completed on ${serverName}. Server is now available.` });
    }
    else {
        res.status(400).json({ message: 'Invalid server name' });
    }
});
// Retained Your Dynamic Routing
app.use('/api/server_Check/:serverName/:service/:status', (req, res, next) => {
    let { serverName, service, status } = req.params;
    console.log(`Received request for server: ${serverName}, service: ${service}, status: ${status}`);
    serverName = serverName.replace(/^\/+|\/+$/g, '');
    console.log(`Cleaned server name: ${serverName}`);
    const serverUrl = getServerUrl(serverName);
    if (serverUrl) {
        const fullUrl = `${serverUrl}/api/${serverName}/${service}/${status}`;
        console.log(`Proxying to: ${fullUrl}`);
        (0, http_proxy_middleware_1.createProxyMiddleware)({
            target: fullUrl,
            changeOrigin: true,
            pathRewrite: { '^/api/': '/' },
            onError(err, _req, res) {
                console.error(`Error connecting to ${serverUrl}:`, err);
                res.status(500).json({ message: 'Error connecting to the backend', error: err.message });
            },
        })(req, res, next);
    }
    else {
        res.status(404).json({ message: 'Server not found' });
    }
});
// Mounting Your Original Routers
app.use('/api/TransactionCounts/Daily', dailyCounts_1.default);
app.use('/api/TransactionCounts/Schedule', Schedule_1.default);
app.use('/api/TransactionCounts/ProcessQueue', ProcessQueue_1.default);
// Confirm WebSocket is Running
app.get('/ws/status', (req, res) => {
    res.json({ message: 'WebSocket running on ws://localhost:5002' });
});
// Start Proxy Server
app.listen(port, () => {
    console.log(`Proxy server running on http://localhost:${port}`);
    console.log(`WebSocket server running on ws://localhost:5002`);
    console.log('Proxy server initialized and scheduled task started.');
});
