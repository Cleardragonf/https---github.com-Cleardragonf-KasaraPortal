"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkAndStartWaitingProcess = void 0;
const node_cron_1 = __importDefault(require("node-cron"));
const node_fetch_1 = __importDefault(require("node-fetch"));
const proxyserver_1 = require("../../proxyserver"); // Adjust the path if needed
const mssql_1 = __importDefault(require("mssql"));
const utils_1 = require("../../utils"); // Adjust path if necessary
// Function to update the process status and LastSuccessfulRun
const updateProcessStatus = (processId, status, lastSuccessfulRun) => __awaiter(void 0, void 0, void 0, function* () {
    console.log(`Updating process ${processId} with status '${status}' and LastSuccessfulRun '${lastSuccessfulRun}'...`);
    try {
        const pool = yield mssql_1.default.connect(utils_1.TranslatorPortal);
        yield pool.request()
            .input('processID', mssql_1.default.UniqueIdentifier, processId)
            .input('status', mssql_1.default.VarChar(30), status)
            .input('lastSuccessfulRun', mssql_1.default.DateTime, lastSuccessfulRun)
            .query(`
                UPDATE ProcessQueue
                SET Status = @status
                WHERE processID = @processID
            `);
        console.log(`Process ${processId} updated successfully.`);
    }
    catch (error) {
        console.error(`Error updating process ${processId}:`, error);
    }
});
// Function to check and process waiting transactions
const checkAndStartWaitingProcess = () => __awaiter(void 0, void 0, void 0, function* () {
    console.log('checkAndStartWaitingProcess: Starting process...');
    try {
        // Connect to SQL Server and fetch waiting processes
        const pool = yield mssql_1.default.connect(utils_1.TranslatorPortal);
        const result = yield pool
            .request()
            .query(`SELECT TOP 1 * FROM ProcessQueue WHERE status = 'waiting' ORDER BY position ASC, weight DESC`);
        if (result.recordset.length === 0) {
            console.log('checkAndStartWaitingProcess: No waiting processes found.');
            return;
        }
        const process = result.recordset[0];
        const { processID, transactionType, year, month } = process;
        console.log('checkAndStartWaitingProcess: Found waiting process:', process);
        // Find an available server
        const availableServer = (0, proxyserver_1.getAvailableServer)();
        if (!availableServer) {
            console.log('checkAndStartWaitingProcess: No available servers. Skipping process execution.');
            return;
        }
        // Mark the server as busy
        proxyserver_1.serverStatus[availableServer] = true;
        // Build the API request URL
        const serverUrl = `${proxyserver_1.serverMapping[availableServer]}/api/TransactionCounts/Start/${transactionType}/${year}/${month}/${processID}`;
        // Call the API to start processing
        try {
            console.log(`checkAndStartWaitingProcess: Triggering process ${processID} on server ${availableServer}...`);
            const response = yield (0, node_fetch_1.default)(serverUrl, { method: 'GET' });
            const data = yield response.json();
            console.log(`checkAndStartWaitingProcess: Process ${processID} started on ${availableServer}. Response:`, data);
            // Update database to mark the process as "in-progress"
            // await pool.request()
            //     .input('processID', sql.UniqueIdentifier, processID)
            //     .query(`UPDATE ProcessQueue SET Status = 'pending', Server = '${availableServer}' WHERE processID = @processID`);
            // console.log(`checkAndStartWaitingProcess: Process ${processID} marked as 'pending' on server ${availableServer}.`);
            // Example usage of the function
            yield updateProcessStatus(processID, 'complete', new Date().toISOString());
        }
        catch (error) {
            console.error(`checkAndStartWaitingProcess: Error starting process ${processID}:`, error);
            proxyserver_1.serverStatus[availableServer] = false; // Mark server as available again
        }
    }
    catch (error) {
        console.error('checkAndStartWaitingProcess: Error checking process queue:', error);
    }
});
exports.checkAndStartWaitingProcess = checkAndStartWaitingProcess;
// Schedule the cron job to run every minute
node_cron_1.default.schedule('* * * * *', () => __awaiter(void 0, void 0, void 0, function* () {
    console.log("Checking process queue...");
    yield (0, exports.checkAndStartWaitingProcess)();
}));
