"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessCleaner = void 0;
const node_cron_1 = __importDefault(require("node-cron"));
const mssql_1 = __importDefault(require("mssql"));
const utils_1 = require("../../utils");
const proxyserver_1 = require("../../proxyserver");
class ProcessCleaner {
    constructor() { }
    static getInstance() {
        if (!ProcessCleaner.instance) {
            ProcessCleaner.instance = new ProcessCleaner();
        }
        return ProcessCleaner.instance;
    }
    // Function to remove completed processes and notify clients
    removeCompletedProcesses() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield mssql_1.default.connect(utils_1.TranslatorPortal);
                const result = yield mssql_1.default.query('EXEC RemoveCompletedProcesses');
                console.log('Completed processes removed');
                // Notify WebSocket clients about removed processes
                const message = {
                    type: 'DBCleanup',
                    subtype: 'ProcessQueue',
                    status: 'completed',
                    timestamp: new Date().toISOString(),
                };
                proxyserver_1.wss.clients.forEach(client => {
                    if (client.readyState === client.OPEN) {
                        client.send(JSON.stringify(message));
                    }
                });
            }
            catch (err) {
                console.error('Error removing completed processes:', err);
            }
        });
    }
    // Schedule the task to run at the specified interval
    scheduleTask() {
        node_cron_1.default.schedule('* * * * *', () => __awaiter(this, void 0, void 0, function* () {
            yield this.removeCompletedProcesses();
        }));
        console.log('Scheduled task to remove completed processes every hour.');
    }
}
exports.ProcessCleaner = ProcessCleaner;
// Initialize and schedule the task
const processCleaner = ProcessCleaner.getInstance();
processCleaner.scheduleTask();
